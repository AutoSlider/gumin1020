// JQuery ver.
$(document).ready(function(){
    //check page loaded
    console.log("document load!");


});

